<?php


//settings key for live site 

//define("CLIENT_ID", "3MVG9fMtCkV6eLhcZRDxkfhX4nsDrfWFYWmWQhkdQBPkhRtLHPF4JRSbQp6m7MmpkuzIqWmgCJx.oDmboDSAX");
//define("CLIENT_SECRET", "9202231034327064732");
//define("REDIRECT_URI", "https://srcdemo.wpengine.com/wp-content/plugins/active-saleforce-account/oAth-responce.php");



//settings for staging

define("REDIRECT_URI", "https://srcdemo.staging.wpengine.com/wp-content/plugins/active-saleforce-account/oAth-responce.php");
define("CLIENT_ID", "3MVG9Y6d_Btp4xp5.SIezjlmUZm6xC7wOpmRB.NLlOEiWm7yaW4L_aC8SNxtQ87OhSOcGGe3uVu2WiEixwDK3");
define("CLIENT_SECRET", "4887576683398102777");





define("LOGIN_URI", "https://login.salesforce.com");

?>